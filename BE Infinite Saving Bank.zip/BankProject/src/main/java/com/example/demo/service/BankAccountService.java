package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.example.demo.exceptions.DuplicateUserException;
import com.example.demo.model.BankAccount;
import com.example.demo.model.User;
import com.example.demo.repository.BankAccountRepository;
import java.util.List;

@Service
public class BankAccountService {

    @Autowired
    private BankAccountRepository bankAccountRepository;
    
    

    public BankAccount createBankAccount(BankAccount bankAccount) {
    	
    	if (bankAccountRepository.existsByAccountNumber(bankAccount.getAccountNumber())) {
    		throw new DuplicateUserException("Account number already exists for another account");
        }
        List<BankAccount> userAccounts = bankAccountRepository.findByUser(bankAccount.getUser());

    	if (userAccounts.isEmpty()) {
            bankAccount.setPrimary(true);
        }
        return  bankAccountRepository.save(bankAccount);
        
    }

    public BankAccount getBankAccountById(Long id) {
        return bankAccountRepository.findById(id).orElse(null);
    }

    public List<BankAccount> getBankAccountsByUser(Long userId) {
        return bankAccountRepository.findByUserId(userId);
    }

    public BankAccount updateBankAccount(Long id, BankAccount bankAccount) {
        BankAccount existingAccount = bankAccountRepository.findByid(id);

        if (!bankAccount.getAccountNumber().equals(existingAccount.getAccountNumber()) && bankAccountRepository.existsByAccountNumber(bankAccount.getAccountNumber())) {
            throw new DuplicateUserException("Account number already exists for another account");
        }
        else {
        	if (bankAccountRepository.existsById(id)) {
        		bankAccount.setId(id);
        		  if (bankAccount.isPrimary()) {
        	            // Clear the primary flag for other accounts of the user
        	            clearPrimaryFlagForOtherAccounts(bankAccount.getUser(), id);
        	        }
            
        	}
        	return bankAccountRepository.save(bankAccount);
        }
        
        
    }
    private void clearPrimaryFlagForOtherAccounts(User user, Long currentAccountId) {
        List<BankAccount> userAccounts = bankAccountRepository.findByUser(user);
        for (BankAccount account : userAccounts) {
            if (!account.getId().equals(currentAccountId)) {
                account.setPrimary(false);
            }
        }
    }
    


    public void deleteBankAccount(Long id) {
        bankAccountRepository.deleteById(id);
    }
}
