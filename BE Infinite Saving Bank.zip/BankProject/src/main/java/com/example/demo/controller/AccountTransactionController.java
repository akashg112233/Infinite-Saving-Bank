package com.example.demo.controller;

import com.example.demo.model.AccountTransaction;
import com.example.demo.service.AccountTransactionService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/transactions")
public class AccountTransactionController {

	@Autowired
	private final AccountTransactionService accountTransactionService;
	
	 @Autowired
	    private JdbcTemplate jdbcTemplate;

	    @GetMapping("/all")
	    public List<Map<String, Object>> getAllTransactionsUser() {
	        String sql = "SELECT * FROM account_trans"; 
	        return jdbcTemplate.queryForList(sql);
	    }

    
    public AccountTransactionController(AccountTransactionService accountTransactionService) {
        this.accountTransactionService = accountTransactionService;
    }

    @GetMapping
    public List<AccountTransaction> getAllTransactions() {
        return accountTransactionService.getAllTransactions();
    	
//    	String sql = "SELECT * FROM your_view_name";  // Replace with your actual view name
//        return jdbcTemplate.queryForList(sql);
    }

    @GetMapping("/{id}")
    public ResponseEntity<AccountTransaction> getTransactionById(@PathVariable Long id) {
        AccountTransaction transaction = accountTransactionService.getTransactionById(id);
        return ResponseEntity.ok(transaction);
    }

    @PostMapping
    public ResponseEntity<?> createTransaction(@Valid @RequestBody AccountTransaction transaction, BindingResult bindingResult) {
//    	return new ResponseEntity<>(transaction, HttpStatus.CREATED);
    	if (bindingResult.hasErrors()) {
    		List<String> errorMessages = bindingResult.getFieldErrors().stream()
                    .map(error -> error.getField() + ": " + error.getDefaultMessage())
                    .collect(Collectors.toList());

    	        return ResponseEntity.badRequest().body(errorMessages);
        }
    	else {
    	AccountTransaction createdTransaction = accountTransactionService.createTransaction(transaction);
        return new ResponseEntity<>(createdTransaction, HttpStatus.CREATED);
    	}
    }


}
