package com.example.demo.model;


import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;


public class AddMoney {
    

    @NotNull(message = "UserId is required")
    private Long userId;

    @NotNull(message = "AccountNumber is required")
    private String accountNumber;

    @NotNull(message = "Available amount is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Available amount must be greater than 0")
    private Double amount;

    public AddMoney() {
        // Default constructor
    }

    public AddMoney(Long userId, String accountNumber, Double amount) {
        this.userId = userId;
        this.accountNumber = accountNumber;
        this.amount = amount;
    }



    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }
}

