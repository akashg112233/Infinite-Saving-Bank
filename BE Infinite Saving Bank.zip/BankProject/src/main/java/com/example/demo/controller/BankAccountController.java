package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.BankAccount;
import com.example.demo.service.BankAccountService;

import jakarta.validation.Valid;

import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/bank-accounts")
public class BankAccountController {

    @Autowired
    private BankAccountService bankAccountService;

    @PostMapping
    public ResponseEntity<?> createBankAccount(@Valid @RequestBody BankAccount bankAccount, BindingResult bindingResult) {
            if (bindingResult.hasErrors()) {
            	List<String> errorMessages = bindingResult.getFieldErrors().stream()
                        .map(error -> error.getField() + ": " + error.getDefaultMessage())
                        .collect(Collectors.toList());

    	        return ResponseEntity.badRequest().body(errorMessages);
        }
            else {
           BankAccount bankAcc= bankAccountService.createBankAccount(bankAccount);
    	 	return new ResponseEntity<>(bankAcc,HttpStatus.CREATED);
            }
    }

    @GetMapping("/{id}")
    public BankAccount getBankAccountById(@PathVariable Long id) {
        return bankAccountService.getBankAccountById(id);
    }

    @GetMapping("/user/{userId}")
    public List<BankAccount> getBankAccountsByUser(@PathVariable Long userId) {
        return bankAccountService.getBankAccountsByUser(userId);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateBankAccount(@PathVariable Long id,@Valid @RequestBody BankAccount bankAccount, BindingResult bindingResult) {
    	if (bindingResult.hasErrors()) {
    		List<String> errorMessages = bindingResult.getFieldErrors().stream()
    	            .map(FieldError::getDefaultMessage)
    	            .collect(Collectors.toList());

    	        return ResponseEntity.badRequest().body(errorMessages);
        }
    	else {
    		BankAccount bankacc =	bankAccountService.updateBankAccount(id, bankAccount);
    		return new ResponseEntity<>(bankacc, HttpStatus.CREATED);
    	}
         
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteBankAccount(@PathVariable Long id) {
        bankAccountService.deleteBankAccount(id);
        return new ResponseEntity<>("Account Deleted",HttpStatus.NO_CONTENT);
    }
}

