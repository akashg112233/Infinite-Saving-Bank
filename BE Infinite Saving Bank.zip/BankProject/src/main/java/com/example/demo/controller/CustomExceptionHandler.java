package com.example.demo.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.example.demo.exceptions.DuplicateUserException;
import com.example.demo.model.CustomException;

import jakarta.validation.ValidationException;

@ControllerAdvice
public class CustomExceptionHandler {
	
//	@ExceptionHandler(MethodArgumentNotValidException.class)
//    public ResponseEntity<String> handleValidationExceptions(MethodArgumentNotValidException ex) {
//        BindingResult result = ex.getBindingResult();
//        StringBuilder errorMessages = new StringBuilder();
//        for (FieldError fieldError : result.getFieldErrors()) {
//            errorMessages.append(fieldError.getDefaultMessage()).append(". ");
//        }
//        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorMessages.toString());
//    }

    @ExceptionHandler(CustomException.class)
    public ResponseEntity<String> handleCustomException(CustomException ex) {
        return ResponseEntity.badRequest().body(ex.getMessage());
    }
    
    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<String> handleValidationException(ValidationException ex) {
    	return ResponseEntity.badRequest().body(ex.getMessage());
    }
    
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<String> handleIllegal(ValidationException ex) {
    	return ResponseEntity.badRequest().body(ex.getMessage());
    }
    
    
    
    
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<?> handleValidationExceptions(MethodArgumentNotValidException ex) {
        BindingResult bindingResult = ex.getBindingResult();
        List<FieldError> fieldErrors = bindingResult.getFieldErrors();
        List<String> errorMessages = fieldErrors.stream()
            .map(error -> error.getDefaultMessage())
            .collect(Collectors.toList());
        return ResponseEntity.badRequest().body(errorMessages);
    }
    
    
    @ExceptionHandler(DuplicateUserException.class)
    public ResponseEntity<String> handleDuplicateUserException(DuplicateUserException ex) {
        return ResponseEntity.badRequest().body(ex.getMessage());
    }


    


    // You can define additional exception handlers for other exception types here
}

