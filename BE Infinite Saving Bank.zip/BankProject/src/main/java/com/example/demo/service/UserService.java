package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.example.demo.exceptions.DuplicateUserException;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public User registerUser(User user) {

        if (userRepository.findByUsername(user.getUsername()) != null) {
            throw new DuplicateUserException("Username is already in use.");
        }

        if (userRepository.findByEmail(user.getEmail()) != null) {
            throw new DuplicateUserException("Email is already in use.");
        }

        // Save the user to the database
        return userRepository.save(user);
    }
    
    
    public List<User> getAllUsers() {

    	return userRepository.findByIsActive(true);
    }

    public User getUserById(Long id) {
    	
    	return userRepository.findById(id).orElse(null);
    }

    public User updateUser(Long id, User user) {
    	// Check if the user with the given ID exists
        User existingUser = userRepository.findById(id).orElse(null);

        if (existingUser == null) {
        	throw new DuplicateUserException("User not found.");
        }


        if (!user.getUsername().equals(existingUser.getUsername()) && userRepository.existsByUsername(user.getUsername())) {
        	throw new DuplicateUserException("Username is already in use.");
        }

        // Check if the new email is already used by another user
        if (!user.getEmail().equals(existingUser.getEmail()) && userRepository.existsByEmail(user.getEmail())) {
        	throw new DuplicateUserException("Email is already in use.");
        }

        // Update the user's information
        existingUser.setUsername(user.getUsername());
        existingUser.setFirstName(user.getFirstName());
        existingUser.setLastName(user.getLastName());
        existingUser.setPhoneNumber(user.getPhoneNumber());
        existingUser.setPassword(user.getPassword());
        // Save the updated user
        User updatedUser = userRepository.save(existingUser);
        return updatedUser;
    
    }

//    public boolean deleteUser(Long id) {
//        // Implement logic to delete a user from the database
//    }
}

