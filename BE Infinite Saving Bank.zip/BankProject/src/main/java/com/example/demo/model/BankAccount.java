package com.example.demo.model;

import org.hibernate.validator.constraints.NotBlank;

import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

@Entity
public class BankAccount {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "accountNumber  is required")
    private String accountNumber;

    @NotBlank(message = "accountType is required")
    private String accountType;

    @NotNull(message = "Available amount is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Available amount must be greater than 0")
    private double availableAmount; 

    
    private boolean isActive; 
    
    private boolean isPrimary;

    
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	public boolean isPrimary() {
        return isPrimary;
    }

    public void setPrimary(boolean primary) {
        isPrimary = primary;
    }

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getAvailableAmount() {
		return availableAmount;
	}

	public void setAvailableAmount(double availableAmount) {
		this.availableAmount = availableAmount;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	

	public BankAccount(Long id, @NotBlank(message = "accountNumber  is required") String accountNumber,
			@NotBlank(message = "accountType is required") String accountType,
			@NotBlank(message = "availableAmount is required") double availableAmount, boolean isActive, User user) {
		super();
		this.id = id;
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.availableAmount = availableAmount;
		this.isActive = isActive;
		this.user = user;
	}
	
	

	@Override
	public String toString() {
		return "BankAccount [id=" + id + ", accountNumber=" + accountNumber + ", accountType=" + accountType
				+ ", availableAmount=" + availableAmount + ", isActive=" + isActive + ", user=" + user + "]";
	}

	public BankAccount() {
		super();
		this.isActive=true;
		this.isPrimary = false;
	} 

    
}

