package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.example.demo.exceptions.DuplicateUserException;
import com.example.demo.model.LoginRequest;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

@Service
public class LoginService {
    @Autowired
    private UserRepository userRepository; // Inject your UserRepository

    public User login(LoginRequest loginRequest) {

        String usernameOrEmail = loginRequest.getUsernameOrEmail();
        String password = loginRequest.getPassword();

        User user = userRepository.findByUsernameOrEmail(usernameOrEmail, usernameOrEmail);
        
        if(user.isActive()==false) {
        	throw new DuplicateUserException("Account is Inactive.Please Contact Admin");
        }
        
        if (user != null && user.getPassword().equals(password) && user.isActive()==true) {
            // Authentication successful, generate a response
            
            return user;

        }
        
        // Authentication failed
        throw new DuplicateUserException("Login Failed");
    }
}

