package com.example.demo.model;


import java.util.Date;
import java.util.List;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    
    @NotBlank(message = "Username is required")
    private String username;
    
    
    @NotBlank(message = "First Name is required")
    private String firstName;
    
    
    @NotBlank(message = "Last Name is required")
    private String lastName;
    
    @Size(min=10,max = 10, message = "Phone Number must be  10 characters")
    private String phoneNumber;
    
    
    @Email(message = "Please provide a valid email")
    @NotBlank(message = "Please provide a valid email")
    private String email;
    
    @NotBlank(message = "Password is required")
    @Size(min = 6, message = "Password must be at least 6 characters")
    private String password;
    
    @CreatedDate
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @LastModifiedDate
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedDate;
    
    private String role;
    
    

	public String getRole() {
		return role;
	}
	
//	 public BankAccount getPrimaryAccount() {
//	        return primaryAccount;
//	    }
//	 
//	 public void setPrimaryAccount(BankAccount primaryAccount) {
//	        this.primaryAccount = primaryAccount;
//	    }

	public void setRole(String role) {
		this.role = role;
	}
//	@OneToOne(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY,orphanRemoval = true)
//    private BankAccount primaryAccount;
	
	
	 @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	    private List<BankAccount> accounts;

    
    @PrePersist
    protected void onCreate() {
    	createdDate = new Date();
    }

    @PreUpdate
    protected void onUpdate() {
    	modifiedDate = new Date();
    }
    
    private boolean isActive;

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
//	   public List<BankAccount> getAccounts() {
//	        return accounts;
//	    }
//
//	    public void setAccounts(List<BankAccount> accounts) {
//	        this.accounts = accounts;
//	    }
	
	
	
	

	public User(@NotBlank(message = "Username is required") String username,
			@NotBlank(message = "First Name is required") String firstName,
			@NotBlank(message = "Last Name is required") String lastName,
			@Size(min = 10, max = 10, message = "Phone Number must 10 characters") String phoneNumber,
			@Email(message = "Please provide a valid email") String email,
			
			@Size(min = 6, message = "Password must be at least 6 characters") String password) {
		super();
		this.username = username;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.password = password;
	}
	
	public User() {
		this.isActive = true;
	}
	
	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + username + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", phoneNumber=" + phoneNumber + ", email=" + email + ", password=" + password + ", createdDate="
				+ createdDate + ", modifiedDate=" + modifiedDate +"isActive" +isActive +"]";
	}
    
	
    

    
}

