package com.example.demo.service;

import com.example.demo.exceptions.DuplicateUserException;
import com.example.demo.model.AddMoney;
import com.example.demo.model.BankAccount;
import com.example.demo.model.User;
import com.example.demo.repository.BankAccountRepository;
import com.example.demo.repository.UserRepository;


import java.util.Optional;


import org.springframework.stereotype.Service;

@Service
public class AddMoneyService {

    private final UserRepository userRepository;
    private final BankAccountRepository bankAccountRepository;


    public AddMoneyService(UserRepository userRepository, BankAccountRepository bankAccountRepository) {
        this.userRepository = userRepository;
        this.bankAccountRepository = bankAccountRepository;
    }

    public void addMoney(AddMoney addMoney) {
    	 Long userId = addMoney.getUserId();
         String accountNumber = addMoney.getAccountNumber();
         Double amount = addMoney.getAmount();
         
         Optional<User> optionalUser = userRepository.findById(userId);

         // Check if an account with the given accountNumber and userId exists
         Optional<BankAccount> optionalBankAccount = bankAccountRepository
                 .findByAccountNumberAndUser_Id(accountNumber, userId);
         
         
         if(!optionalUser.isPresent()) {
        	 throw new DuplicateUserException("User ID Not Found");
         }
         if(!optionalBankAccount.isPresent()) {
        	 throw new DuplicateUserException("Account Not Found");
         }
         
         
         
         
         if (optionalUser.isPresent() && optionalBankAccount.isPresent()) {
             BankAccount bankAccount = optionalBankAccount.get();

             double updatedBalance = bankAccount.getAvailableAmount() + amount;
             bankAccount.setAvailableAmount(updatedBalance);


             bankAccountRepository.save(bankAccount);

         }

    }

    // Other methods as needed
}
