package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
    User findByEmail(String email);
    List<User> findAll(); 
    List<User> findByIsActive(boolean isActive);
    User findByid(Long id);
    boolean existsByUsername(String username);
    User findByUsernameOrEmail(String username, String email);
    boolean existsByEmail(String email);
}

