package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.BankAccount;
import com.example.demo.model.Beneficiary;


public interface BeneficiaryRepository extends JpaRepository<Beneficiary, Long> {
	boolean existsByAccountNumberAndBeneficiaryNameAndCreatedBy(String accountNumber, String beneficiaryName, String createdBy);
	Beneficiary findByAccountNumberAndCreatedBy(String accountNumber , String createdBy);
	List<Beneficiary> findByCreatedBy(String createdBy);
}
