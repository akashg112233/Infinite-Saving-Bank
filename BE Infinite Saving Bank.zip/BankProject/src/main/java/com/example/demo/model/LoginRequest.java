package com.example.demo.model;

import org.hibernate.validator.constraints.NotBlank;

import jakarta.validation.constraints.Size;

public class LoginRequest {
	
	@NotBlank(message = "Username or Email is required")
	private String usernameOrEmail;
    
    @NotBlank(message = "Password is required")
    @Size(min = 6, message = "Password must be at least 6 characters")
    private String password;

    public String getUsernameOrEmail() {
        return usernameOrEmail;
    }

    public void setUsernameOrEmail(String usernameOrEmail) {
        this.usernameOrEmail = usernameOrEmail;
    }
    
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

	public LoginRequest(@NotBlank(message = "Username or Email is required") String usernameOrEmail,
			@NotBlank(message = "Password is required") @Size(min = 6, message = "Password must be at least 6 characters") String password) {
		super();
		this.usernameOrEmail = usernameOrEmail;
		this.password = password;
	}
	
	public LoginRequest() {
		
	}

	@Override
	public String toString() {
		return "LoginRequest [usernameOrEmail=" + usernameOrEmail + ", password=" + password + "]";
	}
	
}

