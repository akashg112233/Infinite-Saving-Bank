package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.BankAccount;
import com.example.demo.model.Beneficiary;
import com.example.demo.service.BeneficiaryService;

import jakarta.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/beneficiaries")
public class BeneficiaryController {

    @Autowired
    private BeneficiaryService beneficiaryService;

    @PostMapping
    public ResponseEntity<?> createBeneficiary(@Valid @RequestBody Beneficiary beneficiary, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
        	List<String> errorMessages = bindingResult.getFieldErrors().stream()
                    .map(error -> error.getField() + ": " + error.getDefaultMessage())
                    .collect(Collectors.toList());

            return ResponseEntity.badRequest().body(errorMessages);
        } else {
            Beneficiary createdBeneficiary = beneficiaryService.createBeneficiary(beneficiary);
            return new ResponseEntity<>(createdBeneficiary, HttpStatus.CREATED);
        }
    }
    
    @GetMapping("/user/{userId}")
    public List<Beneficiary> getBeneficiaryByUser(@PathVariable String userId) {
        return beneficiaryService.getBeneficiaryByUser(userId);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Beneficiary> getBeneficiaryById(@PathVariable Long id) {
        Beneficiary beneficiary = beneficiaryService.getBeneficiaryById(id);
        if (beneficiary != null) {
            return ResponseEntity.ok(beneficiary);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping
    public List<Beneficiary> getAllBeneficiaries() {
        return beneficiaryService.getAllBeneficiaries();
    }

//    @PutMapping("/{id}")
//    public ResponseEntity<Beneficiary> updateBeneficiary(@PathVariable Long id, @RequestBody Beneficiary beneficiary) {
//        Beneficiary updatedBeneficiary = beneficiaryService.updateBeneficiary(id, beneficiary);
//        if (updatedBeneficiary != null) {
//            return ResponseEntity.ok(updatedBeneficiary);
//        } else {
//            return ResponseEntity.notFound().build();
//        }
//    }
//
//    @DeleteMapping("/{id}")
//    public ResponseEntity<Void> deleteBeneficiary(@PathVariable Long id) {
//        boolean deleted = beneficiaryService.deleteBeneficiary(id);
//        return deleted ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
//    }
}

