package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.BankAccount;
import com.example.demo.model.User;

import java.util.List;
import java.util.Optional;

@Repository
public interface BankAccountRepository extends JpaRepository<BankAccount, Long> {
    
    List<BankAccount> findByUserId(Long userId);
    List<BankAccount> findByUser(User user);
    BankAccount findByAccountNumberAndIdNot(String accoutNumber,Long userId);
    boolean existsByAccountNumber(String accountNumber);
    BankAccount findByid(Long id);
    BankAccount findByAccountNumber(String accountNumber);
    Optional<BankAccount> findByAccountNumberAndUser_Id(String accountNumber,Long userId);
    BankAccount findByUserIdAndIsPrimaryTrue(Long userId);

}
