package com.example.demo.service;

import com.example.demo.exceptions.DuplicateUserException;
import com.example.demo.model.AccountTransaction;
import com.example.demo.model.BankAccount;
import com.example.demo.repository.AccountTransactionRepository;
import com.example.demo.repository.BankAccountRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class AccountTransactionService {

	@Autowired
	private  AccountTransactionRepository accountTransactionRepository;
	@Autowired
    private BankAccountRepository bankAccountRepository;
	



    public List<AccountTransaction> getAllTransactions() {
    	return accountTransactionRepository.getAllTransactionsNative();
    }
    
    

    public AccountTransaction getTransactionById(Long id) {
        return accountTransactionRepository.findById(id).orElse(null);
    }

    public AccountTransaction createTransaction(AccountTransaction transaction) {
    	BankAccount account = bankAccountRepository.findByid(Long.parseLong(transaction.getFromUserAccount()));
    	// Add any business logic or validation before saving
    	if(account.getAvailableAmount()-100<transaction.getAmount()) {
    		throw new DuplicateUserException("Transaction Failed because you dont have enough balance. Your Account Balanace is  :"+account.getAvailableAmount()+".\nMinimum 100 Rs Should be there in your account");
    	}
    else {
    	AccountTransaction debitTransaction = new AccountTransaction(
                transaction.getFromUserAccount(),
                transaction.getToUserAccount(),
                transaction.getAmount(),
                "DEBIT",
                transaction.getBeneficiary(),
                transaction.getPurposeToSend()
        );
    	accountTransactionRepository.save(debitTransaction);
    	updateAccountBalance(transaction.getFromUserAccount(), transaction.getAmount(),"DEBIT");
    	if(transaction.getToUserAccount()!=null) {
    	BankAccount acc= bankAccountRepository.findByUserIdAndIsPrimaryTrue(Long.parseLong(transaction.getToUserAccount()));	
        AccountTransaction creditTransaction = new AccountTransaction(
                acc.getId().toString(),
                transaction.getFromUserAccount(),
                transaction.getAmount(),
                "CREDIT",
                transaction.getBeneficiary(),
                transaction.getPurposeToSend()
        );
        accountTransactionRepository.save(creditTransaction);
        updateAccountBalance(acc.getId().toString(), transaction.getAmount(),"CREDIT");
    	}


        
    	return debitTransaction; 
    }
     
     
     

        
    }
    private void updateAccountBalance(String accountNumber, double amount,String transactionType) {
        BankAccount account = bankAccountRepository.findByid(Long.parseLong(accountNumber));

        double updatedBalance = (transactionType.equals("DEBIT")) ?
                account.getAvailableAmount() - amount :
                account.getAvailableAmount() + amount;

        account.setAvailableAmount(updatedBalance);
        bankAccountRepository.save(account);
    }
    
   


//    public void deleteTransaction(Long id) {
//        accountTransactionRepository.deleteById(id);
//    }
    
    // Add more methods as needed
}
