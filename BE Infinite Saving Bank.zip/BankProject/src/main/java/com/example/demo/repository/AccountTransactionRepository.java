package com.example.demo.repository;

import com.example.demo.model.AccountTransaction;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface AccountTransactionRepository extends JpaRepository<AccountTransaction, Long> {
    

	 @Query(value = "SELECT * FROM account_trans", nativeQuery = true)
	 List<AccountTransaction> getAllTransactionsNative();
}
