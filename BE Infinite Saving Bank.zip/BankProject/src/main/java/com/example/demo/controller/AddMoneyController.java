package com.example.demo.controller;

import com.example.demo.model.AddMoney;
import com.example.demo.service.AddMoneyService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/add-money")
public class AddMoneyController {

    @Autowired
    private AddMoneyService addMoneyService;

    @PostMapping
    public ResponseEntity<?> addMoney(@Valid @RequestBody AddMoney addMoney, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            List<String> errorMessages = bindingResult.getFieldErrors().stream()
                    .map(FieldError::getDefaultMessage)
                    .collect(Collectors.toList());

            return ResponseEntity.badRequest().body(errorMessages);
        } else {
            addMoneyService.addMoney(addMoney);
            return new ResponseEntity<>("Money added successfully", HttpStatus.CREATED);
        }
    }

    // Other methods as needed
}
