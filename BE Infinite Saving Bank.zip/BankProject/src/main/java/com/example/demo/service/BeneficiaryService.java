package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exceptions.DuplicateUserException;
import com.example.demo.model.Beneficiary;
import com.example.demo.repository.BeneficiaryRepository;

import java.util.List;

@Service
public class BeneficiaryService {

    @Autowired
    private BeneficiaryRepository beneficiaryRepository;

    public Beneficiary createBeneficiary(Beneficiary beneficiary) {
    	if(beneficiaryRepository.existsByAccountNumberAndBeneficiaryNameAndCreatedBy
    			(beneficiary.getAccountNumber(),beneficiary.getBeneficiaryName(),beneficiary.getCreatedBy())){
    				throw new DuplicateUserException("Beneficiary with same accountNumber is already there.");
    	}
    	Beneficiary ben=beneficiaryRepository.findByAccountNumberAndCreatedBy
		(beneficiary.getAccountNumber(),beneficiary.getCreatedBy());
    	if(ben!=null){
    		throw new DuplicateUserException("Beneficiary already Added By You With Name : "+ben.getBeneficiaryName());
    	}
        return beneficiaryRepository.save(beneficiary);
    }

    public Beneficiary getBeneficiaryById(Long id) {

        return beneficiaryRepository.findById(id).orElse(null);
    }

    public List<Beneficiary> getAllBeneficiaries() {
        
        return beneficiaryRepository.findAll();
    }
    
 public List<Beneficiary> getBeneficiaryByUser(String createdBy) {
        
        return beneficiaryRepository.findByCreatedBy(createdBy);
    }
//    public Beneficiary updateBeneficiary(Long id, Beneficiary beneficiary) {
//        if (beneficiaryRepository.existsById(id)) {
//            beneficiary.Id(id);
//            return beneficiaryRepository.save(beneficiary);
//        } else {
//            return null;
//        }
//    }

//    public boolean deleteBeneficiary(Long id) {
//
//        if (beneficiaryRepository.existsById(id)) {
//            beneficiaryRepository.deleteById(id);
//            return true;
//        } else {
//            return false;
//        }
//    }
}

