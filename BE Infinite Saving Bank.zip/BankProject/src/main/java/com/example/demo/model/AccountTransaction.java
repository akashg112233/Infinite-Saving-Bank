package com.example.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

import java.util.Date;

import org.hibernate.validator.constraints.NotBlank;

@Entity
public class AccountTransaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    
    private String fromUserAccount;

    
    
    private String toUserAccount;
    
    @NotNull(message = "Available amount is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Available amount must be greater than 0")
    private Double amount;
    
    private String transactionType;

    @Temporal(TemporalType.TIMESTAMP)
    private Date createdOn;

   
    private String beneficiary;


    private String purposeToSend;

    public AccountTransaction() {
    	
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFromUserAccount() {
		return fromUserAccount;
	}

	public void setFromUserAccount(String fromUserAccount) {
		this.fromUserAccount = fromUserAccount;
	}

	public String getToUserAccount() {
		return toUserAccount;
	}

	public void setToUserAccount(String toUserAccount) {
		this.toUserAccount = toUserAccount;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(String beneficiary) {
		this.beneficiary = beneficiary;
	}

	public String getPurposeToSend() {
		return purposeToSend;
	}

	public void setPurposeToSend(String purposeToSend) {
		this.purposeToSend = purposeToSend;
	}

	public AccountTransaction(@NotBlank(message = "From User Account is required") String fromUserAccount,
			@NotBlank(message = "To User Account is required") String toUserAccount,
			@NotNull(message = "Available amount is required") @DecimalMin(value = "0.0", inclusive = false, message = "Available amount must be greater than 0") Double amount,
			String transactionType,  String beneficiary, String purposeToSend) {
		super();
		this.fromUserAccount = fromUserAccount;
		this.toUserAccount = toUserAccount;
		this.amount = amount;
		this.transactionType = transactionType;
		this.beneficiary = beneficiary;
		this.purposeToSend = purposeToSend;
	}
    
	 
    

    


}
