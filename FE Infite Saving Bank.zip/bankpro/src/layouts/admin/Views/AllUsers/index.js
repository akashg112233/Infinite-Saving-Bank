import React, { useEffect, useState } from 'react';

import axios from 'axios';
import { API_BASE_URL } from '../../../../config';
import AdminNav from '../../../../components/temp/AdminNav';


const AllUsers = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    // Fetch users from the API
    const fetchUsers = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/users`);
        setUsers(response.data);
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    };

    fetchUsers();
  }, []);

  

  return (
    <>
    <AdminNav />
    <div className="container mt-4">
      <h2>All Users</h2>
      <table id="usersTable" className="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Username</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Phone Number</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.id}>
              <td>{user.id}</td>
              <td>{user.username}</td>
              <td>{user.firstName}</td>
              <td>{user.lastName}</td>
              <td>{user.email}</td>
              <td>{user.phoneNumber}</td>
            
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    </>
  );
};

export default AllUsers;
