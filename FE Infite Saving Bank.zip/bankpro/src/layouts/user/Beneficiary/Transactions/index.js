import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { API_BASE_URL } from '../../../../config';
import { colors } from '../../../../helper/colors';
import NavBar from '../../../../components/NavBar';


const Transactions = () => {
  const [transactions, setTransactions] = useState([]);
  const [user, setUser] = useState(JSON.parse(sessionStorage.getItem('userData')));
  useEffect(() => {
    // Fetch transactions from the API
    const fetchTransactions = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/transactions/all`);
        setTransactions(response.data);
        // console.log(JSON.stringify(response.data));
      } catch (error) {
        console.error('Error fetching transactions:', error);
      }
    };
    console.log(JSON.stringify(user))
    fetchTransactions();
  }, []);
  const filteredTransactions = transactions.filter(transaction => transaction.user_id === user?.id);
  return (
    <>
    <NavBar />
    <div
      className="container"
      style={{
        background: colors.gray,
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <div className="shadow p-4 rounded" style={{ width: '900px', background: colors.white }}>
      <h2>All Transactions</h2>
      <table className="table">
        <thead>
          <tr>
            <th>Transaction ID</th>
            <th>Amount</th>
            <th>Date</th>
            <th>Beneficiary Name</th>
            <th>Account Number</th>
            <th>Transaction Type</th>
          </tr>
        </thead>
        <tbody>
          {filteredTransactions.map((transaction) => (
            <tr key={transaction.id}>
              <td>{transaction.id}</td>
              <td>{transaction.amount}</td>
              <td>{new Date(transaction?.createdon).toLocaleString()}</td>
              <td>{transaction.beneficiary_name}</td> 
              <td>{transaction.account_number}</td> 
              <td>{transaction.transaction_type}</td> 
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    </div>
    </>
  );
};

export default Transactions;
