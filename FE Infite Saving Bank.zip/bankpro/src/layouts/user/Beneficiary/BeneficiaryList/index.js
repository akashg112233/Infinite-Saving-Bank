import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { API_BASE_URL } from '../../../../config';
import NavBar from '../../../../components/NavBar';
import { colors } from '../../../../helper/colors';
import { Link } from 'react-router-dom';

const BeneficiaryList = () => {
  const [beneficiaries, setBeneficiaries] = useState([]);
  const [editBeneficiaryId, setEditBeneficiaryId] = useState(null);
  const [editedBeneficiary, setEditedBeneficiary] = useState({
    beneficiaryName: '',
    bankName: '',
    accountNumber: '',
    ifscCode: '',
  });

  const [user, setUser] = useState(JSON.parse(sessionStorage.getItem('userData')));

  const fetchBeneficiaries = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/beneficiaries/user/${user?.id}`);
      setBeneficiaries(response.data);
    } catch (error) {
      console.error('Error fetching beneficiaries:', error);
    }
  };

  useEffect(() => {
    fetchBeneficiaries();
  }, []);

  const handleEdit = (beneficiaryId) => {
    // Set the beneficiary ID for editing
    setEditBeneficiaryId(beneficiaryId);

    // Find the beneficiary to be edited
    const beneficiaryToEdit = beneficiaries.find(
      (beneficiary) => beneficiary.id === beneficiaryId
    );

    // Set the edited beneficiary details
    setEditedBeneficiary({
      beneficiaryName: beneficiaryToEdit.beneficiaryName,
      bankName: beneficiaryToEdit.bankName,
      accountNumber: beneficiaryToEdit.accountNumber,
      ifscCode: beneficiaryToEdit.ifscCode,
    });
  };

  const handleCancelEdit = () => {
    // Clear the edit state
    setEditBeneficiaryId(null);
    setEditedBeneficiary({
      beneficiaryName: '',
      bankName: '',
      accountNumber: '',
      ifscCode: '',
    });
  };

  const handleSaveEdit = async () => {
    try {
      // Send a PUT request to update the beneficiary details
      await axios.put(
        `${API_BASE_URL}/beneficiaries/${editBeneficiaryId}`,
        editedBeneficiary,
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );

      // Clear the edit state
      setEditBeneficiaryId(null);
      setEditedBeneficiary({
        beneficiaryName: '',
        bankName: '',
        accountNumber: '',
        ifscCode: '',
      });

      // Fetch updated list of beneficiaries
      fetchBeneficiaries();
    } catch (error) {
      console.error('Error updating beneficiary:', error);
    }
  };

  return (
    <>
      <NavBar />
      <div
        className="container"
        style={{
          background: colors.gray,  
          minHeight: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <div
          className="shadow p-4 rounded"
          style={{ width: '800px', background: '#fff' }}
        >
            <button type="button" className="btn btn-secondary">
          <Link className="nav-link" to="/add-beneficiary">Add Beneficiary</Link>
        </button>
          <h2>Beneficiary List</h2>
          <table className="table">
            <thead>
              <tr>
                <th>Beneficiary Name</th>
                <th>Bank Name</th>
                <th>Account Number</th>
                <th>IFSC Code</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {beneficiaries.map((beneficiary) => (
                <tr key={beneficiary.id}>
                  <td>{beneficiary.beneficiaryName}</td>
                  <td>{beneficiary.bankName}</td>
                  <td>{beneficiary.accountNumber}</td>
                  <td>{beneficiary.ifscCode}</td>
                  <td>
                    {editBeneficiaryId === beneficiary.id ? (
                      <>
                        <button
                          className="btn btn-success"
                          onClick={handleSaveEdit}
                        >
                          Save
                        </button>
                        <button
                          className="btn btn-secondary ml-2"
                          onClick={handleCancelEdit}
                        >
                          Cancel
                        </button>
                      </>
                    ) : (
                      <a
                        className="btn btn-primary"
                        
                        href={`/transfer/${beneficiary.id}`}
                      >
                        Transfer Money
                      </a>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};

export default BeneficiaryList;
