import React, { useState } from 'react';
import axios from 'axios';
import { API_BASE_URL } from '../../../../config';
import NavBar from '../../../../components/NavBar';
import { colors } from '../../../../helper/colors';

const AddBeneficiary = () => {
  const [beneficiaryDetails, setBeneficiaryDetails] = useState({
    beneficiaryName: '',
    bankName: '',
    accountNumber: '',
    ifscCode: '',
  });

  const [successMessage, setSuccessMessage] = useState('');
  const [errors, setErrors] = useState();
  const [user, setUser] = useState(JSON.parse(sessionStorage.getItem('userData')));

  const handleChange = (e) => {
    const { name, value } = e.target;
    setBeneficiaryDetails({ ...beneficiaryDetails, [name]: value });

  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const beneficiaryDetailsWithUser = {
        ...beneficiaryDetails,
        createdBy : user.id,
      };

    try {
      const response = await axios.post(
        `${API_BASE_URL}/beneficiaries`,
        beneficiaryDetailsWithUser,
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );

      console.log('Beneficiary added successfully', response.data);
      setErrors('');
      setSuccessMessage('Beneficiary added successfully.');

      // Reset the form
      setBeneficiaryDetails({
        beneficiaryName: '',
        bankName: '',
        accountNumber: '',
        ifscCode: '',
      });
    } catch (error) {
      console.error('Error adding beneficiary:', error);
      setSuccessMessage('');
      setErrors(error?.response?.data );
    }
  };

  return (
    <>
      <NavBar />
      <div
        className="container"
        style={{
          background: colors.gray,  
          minHeight: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <div
          className="shadow p-4 rounded"
          style={{ width: '400px', background: '#fff' }}
        >
          {successMessage && (
            <div className="alert alert-success">{successMessage}</div>
          )}

        {errors && <div className="alert alert-danger">{typeof errors === 'object' ?errors[0]?.substring(errors[0].indexOf(':') + 1).trim():errors}</div>}
          <h2>Add Beneficiary</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="beneficiaryName">Beneficiary Name:</label>
              <input
                type="text"
                id="beneficiaryName"
                name="beneficiaryName"
                value={beneficiaryDetails.beneficiaryName}
                onChange={handleChange}
                className={`form-control`}
              />
              
            </div>
            <div className="form-group">
              <label htmlFor="bankName">Bank Name:</label>
              <input
                type="text"
                id="bankName"
                name="bankName"
                value={beneficiaryDetails.bankName}
                onChange={handleChange}
                className={`form-control`}
              />
              
            </div>
            <div className="form-group">
              <label htmlFor="accountNumber">Account Number:</label>
              <input
                type="text"
                id="accountNumber"
                name="accountNumber"
                value={beneficiaryDetails.accountNumber}
                onChange={handleChange}
                className={`form-control `}
              />
              
            </div>
            <div className="form-group">
              <label htmlFor="ifscCode">IFSC Code:</label>
              <input
                type="text"
                id="ifscCode"
                name="ifscCode"
                value={beneficiaryDetails.ifscCode}
                onChange={handleChange}
                className={`form-control`}
              />
              
            </div>
            <button type="submit" className="btn btn-primary">
              Add Beneficiary
            </button>
          </form>
        </div>
      </div>
    </>
  );
};

export default AddBeneficiary;
