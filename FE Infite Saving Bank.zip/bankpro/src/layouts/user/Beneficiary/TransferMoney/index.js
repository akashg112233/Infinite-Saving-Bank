import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { API_BASE_URL } from '../../../../config';
import NavBar from '../../../../components/NavBar';
import { useParams } from 'react-router-dom';

const TransferMoney = () => {
  const [transactionData, setTransactionData] = useState({
    fromUserAccount: '',
    toUserAccount: '',
    amount: 0,
    transactionType: '',
    beneficiary: '',
    purposeToSend: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { beneficiaryId } = useParams(); 
  const [beneficiaryDetails, setBeneficiaryDetails] = useState({});
  const [user, setUser] = useState(JSON.parse(sessionStorage.getItem('userData')));
  const [successMessage, setSuccessMessage] = useState('');
  const [errors, setErrors] = useState();
  const [accounts, setAccounts] = useState([]);

  const fetchAccounts = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/bank-accounts/user/${user?.id}`);
      setAccounts(response.data);
    } catch (error) {
      console.error('Error fetching accounts:', error);
      setError('Error fetching account details.');
    }
  };
  useEffect(() => {
    

    fetchAccounts();
  }, []);


  const fetchBeneficiary = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/beneficiaries/${beneficiaryId}`);
      setBeneficiaryDetails(response.data);
    } catch (error) {
      console.error('Error fetching beneficiary:', error);
      setError('Error fetching beneficiary details.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBeneficiary();
  }, []);

  const handleChange = (e) => {
    setSuccessMessage('');
    setErrors('');
    const { name, value } = e.target;
    setTransactionData({ ...transactionData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const transactionDataWithUser = {
        ...transactionData,
        beneficiary:beneficiaryId,
        transactionType: null,
        toUserAccount: null,
      };
    try {
      
      // Send a POST request to create a new transaction
      await axios.post(`${API_BASE_URL}/transactions`, transactionDataWithUser, {
        headers: {
          'Content-Type': 'application/json',
        },
      });

      // Reset the form after successful submission
      setTransactionData({
        fromUserAccount: '',
        toUserAccount: '',
        amount: 0,
        transactionType: '',
        beneficiary: '',
        purposeToSend: '',
      });
      setErrors('');
      fetchAccounts();
      setSuccessMessage('Transaction Done ...!');
    } catch (error) {
      console.error('Error creating transaction:', error);
      setSuccessMessage('');
      setErrors(error?.response?.data);

    } 
  };

  return (
    <>
      <NavBar />
      <div
        className="container"
        style={{
          minHeight: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <div
          className="shadow p-4 rounded"
          style={{ width: '400px', background: '#fff' }}
        >
            {successMessage && (
            <div className="alert alert-success">{successMessage}</div>
          )}
            {errors && <div className="alert alert-danger">{typeof errors === 'object' ?errors[0]?.substring(errors[0].indexOf(':') + 1).trim():errors}</div>}
          <h2>Send Money</h2>
          <p>
                <strong>Beneficiary Name:</strong> {beneficiaryDetails.beneficiaryName}
              </p>
              <p>
                <strong>Bank Name:</strong> {beneficiaryDetails.bankName}
              </p>
              <p>
                <strong>Account Number:</strong> {beneficiaryDetails.accountNumber}
              </p>
              <p>
                <strong>IFSC Code:</strong> {beneficiaryDetails.ifscCode}
              </p>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="fromUserAccount">From User Account:</label>
              <select
                id="fromUserAccount"
                name="fromUserAccount"
                value={transactionData.fromUserAccount}
                onChange={handleChange}
                className="form-control"
              >
                <option value="" disabled>Select account</option>
                {accounts.map((account) => (
                  <option key={account.id} value={account.id}>
                    {`${account.accountNumber} (Balance: ${account.availableAmount})`}
                  </option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label htmlFor="toUserAccount" hidden>To User Account:</label>
              <input
                type="text"
                id="toUserAccount"
                name="toUserAccount"
                value={transactionData.toUserAccount}
                onChange={handleChange}
                className="form-control"
                hidden
              />
            </div>
            <div className="form-group">
              <label htmlFor="amount">Amount:</label>
              <input
                type="number"
                id="amount"
                name="amount"
                value={transactionData.amount}
                onChange={handleChange}
                className="form-control"
              />
            </div>
            {/* <div className="form-group">
              <label htmlFor="transactionType">Transaction Type:</label>
              <input
                type="text"
                id="transactionType"
                name="transactionType"
                value={transactionData.transactionType}
                onChange={handleChange}
                className="form-control"
              />
            </div> */}
            {/* <div className="form-group">
              <label htmlFor="beneficiary">Beneficiary:</label>
              <input
                type="text"
                id="beneficiary"
                name="beneficiary"
                value={transactionData.beneficiary}
                onChange={handleChange}
                className="form-control"
              />
            </div> */}
            <div className="form-group">
              <label htmlFor="purposeToSend">Purpose to Send:</label>
              <input
                type="text"
                id="purposeToSend"
                name="purposeToSend"
                value={transactionData.purposeToSend}
                onChange={handleChange}
                className="form-control"
              />
            </div>
            <br></br>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Submitting...' : 'Submit'}
            </button>
            {error && <p style={{ color: 'red' }}>{error}</p>}
          </form>
        </div>
      </div>
    </>
  );
};

export default TransferMoney;