import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { API_BASE_URL } from '../../../../config';
import NavBar from '../../../../components/NavBar';

const TransactionListPage = () => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/transactions`);
        setTransactions(response.data);
      } catch (error) {
        console.error('Error fetching transactions:', error);
        setError('Error fetching transaction details.');
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, []);

  return (
    <>
      <NavBar />
      <div
        className="container"
        style={{
          minHeight: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <div
          className="shadow p-4 rounded"
          style={{ width: '800px', background: '#fff' }}
        >
          <h2>All Transactions</h2>
          {loading && <p>Loading...</p>}
          {error && <p style={{ color: 'red' }}>{error}</p>}
          {!loading && !error && (
            <table className="table">
              <thead>
                <tr>
                  <th>Transaction ID</th>
                  <th>From User Account</th>
                  <th>To User Account</th>
                  <th>Amount</th>
                  <th>Transaction Type</th>
                  <th>Created On</th>
                  <th>Beneficiary</th>
                  <th>Purpose to Send</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((transaction) => (
                  <tr key={transaction.id}>
                    <td>{transaction.id}</td>
                    <td>{transaction.fromUserAccount}</td>
                    <td>{transaction.toUserAccount}</td>
                    <td>{transaction.amount}</td>
                    <td>{transaction.transactionType || 'N/A'}</td>
                    <td>{transaction.createdOn || 'N/A'}</td>
                    <td>{transaction.beneficiary || 'N/A'}</td>
                    <td>{transaction.purposeToSend || 'N/A'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
};

export default TransactionListPage;
