// AccountDetails.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, useParams } from 'react-router-dom';
import { API_BASE_URL } from '../../../../config';
import NavBar from '../../../../components/NavBar';


const AccountDetails = () => {
  const { id } = useParams(); 
  const [accountDetails, setAccountDetails] = useState({});
  const [editMode, setEditMode] = useState(false);
  const [successMessage,setSuccessMessage] = useState('');
  const [errorMessage,setErrorMessage] = useState('');
  useEffect(() => {
    
    const fetchAccountDetails = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/bank-accounts/${id}`);

        setAccountDetails(response.data);
      } catch (error) {
        console.error('Error fetching account details:', error);
      }
    };

    fetchAccountDetails();
  }, [id]);

  const handleEdit = () => {
    setSuccessMessage('');
    // Enable edit mode
    setEditMode(true);
  };

  const handleSave = async () => {
    // Save changes to the backend
    try {
        console.log(accountDetails)
      await axios.put(`${API_BASE_URL}/bank-accounts/${id}`, accountDetails);

      // Disable edit mode after successful save
      setSuccessMessage('Account Details Updated.');
      setErrorMessage('');
      setEditMode(false);
    } catch (error) {
      console.error('Error saving account details:', error);
      setSuccessMessage('');
      setErrorMessage(error?.response?.data);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setAccountDetails({ ...accountDetails, [name]: value });
  };

  return (<>
    <NavBar />
    <div className="container mt-4">
      {successMessage && <div className="alert alert-success">{successMessage}  <a href='/accounts'>Click here to  goto Account List</a></div>}
      {errorMessage && <div className="alert alert-danger">{errorMessage}  </div>}
      <h2>Account Details</h2>
      
      {editMode ? (
        
        <div>
          
          <div className="form-group">
            <label htmlFor="accountNumber">Account Number</label>
            <input
              type="text"
              id="accountNumber"
              name="accountNumber"
              value={accountDetails.accountNumber}
              onChange={handleChange}
              className="form-control"
            />
          </div>

          <div className="form-group">
            <label htmlFor="accountType">Account Type</label>
            <input
              type="text"
              id="accountType"
              name="accountType"
              value={accountDetails.accountType}
              onChange={handleChange}
              className="form-control"
              disabled
            />
            
          </div>

          <div className="form-group">
            <label htmlFor="availableAmount">Available Amount</label>
            <input
              type="text"
              id="availableAmount"
              name="availableAmount"
              value={accountDetails.availableAmount}
              onChange={handleChange}
              className="form-control"
              disabled
            />
          </div>
          
          <div className="form-check form-switch">
    <input
      className="form-check-input"
      type="checkbox"
      role="switch"
      id="primary"
      name="primary"
      checked={accountDetails.primary}
      onChange={() => setAccountDetails({ ...accountDetails, primary: !accountDetails.primary })}
    />
    <label className="form-check-label" htmlFor="flexSwitchCheckChecked">
      {'Primary Account'}
    </label>
  </div>
          <button type="button" className="btn btn-primary" onClick={handleSave}>
            Save
          </button>
        </div>
      ) : (
        <div>
          
          <p>Account Number: {accountDetails.accountNumber}</p>
          <p>Account Type: {accountDetails.accountType}</p>
          <p>Available Amount: {accountDetails.availableAmount}</p>

          <button type="button" className="btn btn-secondary" onClick={handleEdit}>
            Edit
          </button>
          
        </div>
      )}
    </div>
    </>
  );
};

export default AccountDetails;