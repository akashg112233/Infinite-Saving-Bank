import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { API_BASE_URL } from '../../../../config';
import { colors } from '../../../../helper/colors';
import NavBar from '../../../../components/NavBar';
import { useHistory } from 'react-router-dom';

const AddAccount = () => {
  const [accountDetails, setAccountDetails] = useState({
    accountNumber: '',
    accountType: '', 
    availableAmount: '',
  });
  const [successMessage,setSuccessMessage] = useState('');
  const [user, setUser] = useState(JSON.parse(sessionStorage.getItem('userData')));
  const [errors, setErrors] = useState();
  const history =useHistory();
  
  const createJsonObject = (array) => {
    const jsonObject = {};
  
    for (const item of array) {
      const [key, value] = item.split(':');
      const trimmedKey = key.trim();
      const trimmedValue = value.trim();
  
      jsonObject[trimmedKey] = trimmedValue;
    }
  
    return jsonObject;
  };
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setAccountDetails({ ...accountDetails, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(accountDetails)
    const accountDetailsWithUser = {
        ...accountDetails,
        user: {
          id: user.id,
        },
      };

    console.log(accountDetailsWithUser)
    try {
      const response = await axios.post(`${API_BASE_URL}/bank-accounts`, accountDetailsWithUser, {
        headers: {
          'Content-Type': 'application/json',
        },
      });

      console.log('Account added successfully', response.data);
      setErrors('');
      setSuccessMessage('Account Details added successfully.');
    //   history.push('/accounts');

      // Reset the form
      setAccountDetails({
        accountNumber: '',
        accountType: '',
        availableAmount: '',
      });
    } catch (error) {
      console.error('Error adding account:', error);
      setSuccessMessage('');
      setErrors(error?.response?.data);
      
      
    }
  };

  return (
    <>
    <NavBar />
    <div
      className="container"
      style={{
        background: colors.gray,
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <div className="shadow p-4 rounded" style={{ width: '400px', background: colors.white }}>
      {successMessage && <div className="alert alert-success">{successMessage}<a href='/accounts'>Click here to  goto Account List</a></div>}
      {errors && <div className="alert alert-danger">{typeof errors === 'object' ?errors[0]?.substring(errors[0].indexOf(':') + 1).trim():errors}</div>}
      <h2>Add Account</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="accountNumber">Account Number:</label>
          <input
            type="text"
            id="accountNumber"
            name="accountNumber"
            value={accountDetails.accountNumber}
            onChange={handleChange}
            className="form-control"
          />
          
        </div>
        <div className="form-group">
          <label htmlFor="accountType">Account Type:</label>
          <select
            id="accountType"
            name="accountType"
            value={accountDetails.accountType}
            onChange={handleChange}
            className="form-control"
          >
            <option value="" disabled>Select account type</option>
            <option value="Saving">Saving</option>
            <option value="Current">Current</option>
          </select>
          
        </div>
        <div className="form-group">
          <label htmlFor="availableAmount">Available Amount:</label>
          <input
            type="number"
            id="availableAmount"
            name="availableAmount"
            value={accountDetails.availableAmount}
            onChange={handleChange}
            className="form-control"
          />
        
        </div>
        
       
        <button type="submit" className="btn btn-primary">Add Account</button>
      </form>
    </div>
    </div>
    </>
  );
};

export default AddAccount;