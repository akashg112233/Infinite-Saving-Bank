import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { API_BASE_URL } from '../../../../config';
import NavBar from '../../../../components/NavBar';


const AccountList = () => {
  const [accounts, setAccounts] = useState([]);

  const [user, setUser] = useState(JSON.parse(sessionStorage.getItem('userData')));

    
  useEffect(() => {
    console.log('User ID:', user?.id);

    const fetchAccounts = async () => {
      try {
        if (user?.id) {
          
          const response = await axios.get(`${API_BASE_URL}/bank-accounts/user/${user?.id}`);
          setAccounts(response.data);
        }
      } catch (error) {
        console.error('Error fetching accounts:', error);
      }
    };

    fetchAccounts();
  }, [user]);

  return (<>
  <NavBar />
   <div className="container mt-4">
   <button type="button" className="btn btn-secondary">
          <Link className="nav-link" to="/add-account">Add Account</Link>
    </button>
  <h2>Account List</h2>
  <table className="table">
    <thead>
      <tr>
        <th>Sr No</th>
        <th>Account Number</th>
        <th>Account Details</th>
        <th>Primary Account</th>
      </tr>
    </thead>
    <tbody>
      {accounts.map((account, index) => (
        <tr key={account.id}>
          <td>{index + 1}</td>
          <td>{account.accountNumber}</td>
          <td>
            <a href={`/accounts/${account.id}`}>View Details</a>
          </td>
          <td>{account?.primary ? 'Yes':'No'}</td>
        </tr>
      ))}
    </tbody>
  </table>
</div>

    </>
  );
};

export default AccountList;
