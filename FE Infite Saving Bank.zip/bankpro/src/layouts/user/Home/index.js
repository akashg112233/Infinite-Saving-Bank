import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import NavBar from '../../../components/NavBar';

const Home = () => {
  const [userData, setUserData] = useState(null);
  useEffect(() => {
    const storedUserData = sessionStorage.getItem('userData');
    
    if (storedUserData) {
      // Parse the JSON string to get the user data object
      const parsedUserData = JSON.parse(storedUserData);
      setUserData(parsedUserData);
    }
  }, []);

  // console.log(JSON.stringify(userData));
  console.log(userData?.role==='ADMIN')
  return (
    <div>
       <NavBar />

      <div className="container mt-4">
        <h2>Welcome to the Home Page! {userData?.firstName}</h2>
        {/* Add your home page content here */}
      </div>
    </div>
  );
};

export default Home;