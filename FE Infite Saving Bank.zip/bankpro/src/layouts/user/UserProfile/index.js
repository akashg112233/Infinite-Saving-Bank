import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { API_BASE_URL } from '../../../config';
import { colors } from '../../../helper/colors';
import NavBar from '../../../components/NavBar';

const UserProfile = () => {
  const [userData, setUserData] = useState({
    username: '',
    firstName: '',
    lastName: '',
    phoneNumber: '',
    email: '',
    password: '',
  });
  
  const [successMessage,setSuccessMessage] = useState('');
  const [userDetatils, setUserDetails] = useState(null);
  const [errorMessage,setErrorMessage] = useState('');
  useEffect(() => {
    const storedUserData = sessionStorage.getItem('userData');
    
    if (storedUserData) {
      // Parse the JSON string to get the user data object
      const parsedUserData = JSON.parse(storedUserData);
      console.log(parsedUserData.id);
      setUserDetails(parsedUserData);
    }
  }, []);
  console.log(userDetatils?.id);
  const [editMode, setEditMode] = useState(false);

  useEffect(() => {
    if (userDetatils?.id) {
    const fetchUserData = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/users/${userDetatils?.id}`);

        setUserData(response.data);
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    fetchUserData();
    }
  }, [userDetatils]);

  const handleEditClick = () => {
    setSuccessMessage('');
    setEditMode(true);
  };

  const handleSaveClick = async () => {
    try {
      // Make a PUT request to update the user data
      await axios.put(`${API_BASE_URL}/users/${userDetatils?.id}`, userData);

      setEditMode(false);
      console.log('User data updated successfully!');
      setSuccessMessage('User data updated successfully!');
      setErrorMessage('');
    } catch (error) {
      console.error('Error updating user data:', error);
      setSuccessMessage('');
      setErrorMessage(error?.response?.data);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData((prevData) => ({ ...prevData, [name]: value }));
  };

  return (
    <>
    <NavBar />
    <div
      className="container"
      style={{
        background: colors.gray,
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <div className="shadow p-4 rounded" style={{ width: '500px', background: colors.white }}>
      {errorMessage && <div className="alert alert-danger">{errorMessage}  </div>}
    <h2>User Profile</h2>
    {successMessage && <div className="alert alert-success">{successMessage}</div>}
    {userData ? (
      <form>
        <div className="form-group">
          <label>Id</label>
          {editMode ? (
            <input type="text" value={userData.id} disabled className="form-control" />
          ) : (
            <p>{userData.id}</p>
          )}
        </div>
        <div className="form-group">
          <label>Username</label>
          {editMode ? (
            <input
              type="text"
              name="username"
              value={userData.username}
              onChange={handleChange}
              className="form-control"
            />
          ) : (
            <p>{userData.username}</p>
          )}
        </div>
        <div className="form-group">
          <label>FirstName</label>
          {editMode ? (
            <input
              type="text"
              name="firstName"
              value={userData.firstName}
              onChange={handleChange}
              className="form-control"
            />
          ) : (
            <p>{userData.firstName}</p>
          )}
        </div>
        <div className="form-group">
          <label>LastName</label>
          {editMode ? (
            <input
              type="text"
              name="lastName"
              value={userData.lastName}
              onChange={handleChange}
              className="form-control"
            />
          ) : (
            <p>{userData.lastName}</p>
          )}
        </div>
        <div className="form-group">
          <label>PhoneNumber</label>
          {editMode ? (
            <input
              type="text"
              name="phoneNumber"
              value={userData.phoneNumber}
              onChange={handleChange}
              className="form-control"
            />
          ) : (
            <p>{userData.phoneNumber}</p>
          )}
        </div>
        <div className="form-group">
          <label>Email</label>
          {editMode ? (
            <input
              type="text"
              name="email"
              value={userData.email}
              onChange={handleChange}
              className="form-control"
            />
          ) : (
            <p>{userData.email}</p>
          )}
        </div>
        <div className="form-group">
            <label>Password</label>
            {editMode ? (
              <input
                type="password"
                name="password"
                value={userData.password}
                onChange={handleChange}
                className="form-control"
              />
            ) : (
              <p>********</p>
            )}
          </div>
        {editMode ? (
          <div className="text-center">
            <button type="button" className="btn btn-primary" onClick={handleSaveClick}>
              Save
            </button>
          </div>
        ) : (
          <div className="text-center">
            <button type="button" className="btn btn-primary" onClick={handleEditClick}>
              Edit
            </button>
          </div>
        )}
      </form>
    ) : (
      <p>Loading user data...</p>
    )}
  </div>
  </div>
  </>
  );
};

export default UserProfile;