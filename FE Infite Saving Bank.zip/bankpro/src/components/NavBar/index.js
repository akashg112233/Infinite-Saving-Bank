import React, { useEffect, useState } from 'react';
import { Link, useHistory } from 'react-router-dom';

const NavBar = () => {

    const history = useHistory();
    const [user,setUsers]=useState();
    const handleLogout = () => {
        // Clear user data from session storage
        sessionStorage.removeItem('userData');
        // Redirect to the login page
        history.push('/login');
      };
      useEffect(() => {
        // This effect runs after the component has mounted
      
        // Check if the user is already authenticated (e.g., in session storage)
        const userData = sessionStorage.getItem('userData');
        if (userData) {
          // Redirect to the home page if the user is already authenticated
          setUsers(userData);
        }
      }, [user]);
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      
      <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav mr-auto">
          <li className="nav-item active">
            <Link className="nav-link" to="/">Home</Link>
          </li>
        </ul>

        {/* Right-aligned menu items */}
        <ul className="navbar-nav ml-auto">
          <li className="nav-item">
            <Link className="nav-link" to="/accounts">Accounts</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/beneficiary">Beneficiary</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/user">Profile</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/transactions">Transaction</Link>
          </li>
        </ul>
       {user ? (<ul className="navbar-nav ml-auto">
            <li className="nav-item">
              <button className="btn btn-link nav-link" onClick={handleLogout}>
                Logout
              </button>
            </li>
          </ul>):''}
      </div>
    </nav>

  );
};

export default NavBar;
