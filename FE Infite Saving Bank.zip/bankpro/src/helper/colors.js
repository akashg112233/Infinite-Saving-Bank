export const colors = {
    white:'#fff',
    gray:'#f2f2f2'
  };
  
  