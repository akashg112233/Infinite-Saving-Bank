import './App.css';
import Registration from './auth/Registration';
import { BrowserRouter, Switch, Route } from "react-router-dom";
import Login from './auth/Login';
import { SuccessMessageProvider } from './messages/SuccessMessageContext';
import Home from './layouts/user/Home';
import { createBrowserHistory } from 'history';
import UserProfile from './layouts/user/UserProfile';
import AccountList from './layouts/user/Accounts/AccountList';
import AccountDetails from './layouts/user/Accounts/AccountDetails';
import AddAccount from './layouts/user/Accounts/AddAccount';
import AddBeneficiary from './layouts/user/Beneficiary/AddBeneficiary';
import BeneficiaryList from './layouts/user/Beneficiary/BeneficiaryList';
import TransferMoney from './layouts/user/Beneficiary/TransferMoney';
import Transactions from './layouts/user/Beneficiary/Transactions';
import AllTransactions from './layouts/admin/Views/AllTranscations';
import AdminHome from './layouts/admin/Home';
import AllUsers from './layouts/admin/Views/AllUsers';



const history = createBrowserHistory();
function App() {
  return (
    <BrowserRouter history={history}>
        <Route  path="/registration" exact component={Registration} />
        <Route  path="/login" exact component={Login} />
        <Route  path="/" exact component={Login} />
        <Route  path="/home" exact component={Home} />
        {/* User Routes */}
           <Route path="/user" exact component={UserProfile} />
           <Route path="/accounts/:id" component={AccountDetails} />
            <Route path="/accounts" exact component={AccountList} />
            <Route path="/add-account" component={AddAccount} />
            <Route path="/add-beneficiary" exact component={AddBeneficiary} />
            <Route path="/beneficiary" exact component={BeneficiaryList} />
            <Route path="/transfer/:beneficiaryId" component={TransferMoney} />
            <Route path="/transactions" exact component={Transactions} />
        {/* Admin Routes */}
            <Route path="/all-transactions" exact component={AllTransactions} />
            <Route path="/admin-home" exact component={AdminHome} />
            <Route path="/all-users" exact component={AllUsers} />
      
      
    </BrowserRouter>
  );
}

export default App;
