import React, { useState } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link, useHistory } from 'react-router-dom';
import { useSuccessMessage } from '../../messages/SuccessMessageContext';
import { API_BASE_URL } from '../../config';
import { colors } from '../../helper/colors';
const Registration = () => {
  const initialFormData = {
    username: '',
    firstName: '',
    lastName: '',
    phoneNumber: '',
    email: '',
    password: '',
    confirmPassword: '',
  };
  const history = useHistory();
  const [formData, setFormData] = useState(initialFormData);
  const [errors, setErrors] = useState({});
  const [successMessage,setSuccessMessage] = useState('');
  // const { setSuccessMessage } = useSuccessMessage();


  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const validationErrors = {};

    for (const field in formData) {
      if (!formData[field]) {
        validationErrors[field] = `${field.charAt(0).toUpperCase() + field.slice(1)} is required`;
      }
    }

    if (formData.email && !/\S+@\S+\.\S+/.test(formData.email)) {
      validationErrors.email = 'Email is invalid';
    }

    if (formData.password && formData.password.length < 6) {
      validationErrors.password = 'Password must be at least 6 characters long';
    }

    if (formData.password !== formData.confirmPassword) {
      validationErrors.confirmPassword = 'Passwords do not match';
    }

    if (Object.keys(validationErrors).length === 0) {
      try {
        const response = await axios.post(`${API_BASE_URL}/users`, formData,{
            headers: {
                'Content-Type': 'application/json',
              },
        });

        console.log('User registration successful', response.data);
        setSuccessMessage('User registration successful ');
        // history.go('/login');

        
        setFormData(initialFormData);
        setErrors({});
      } catch (error) {
        
        if (error?.response && error?.response?.status === 400) {
            
            if(error?.response?.data==='Username is already in use.'){
            validationErrors.username = 'Username is already in use';
            }else if(error?.response?.data==='Email is already in use.')
            {
                validationErrors.email = 'Email is already in use';
            }else if(error?.response?.data[0]==='Phone Number must be  10 characters')
            {
                validationErrors.phoneNumber = 'Phone Number must be  10 characters';
            }
            setErrors(validationErrors);
          } else {
            console.error('User registration failed', error);
          }
      }
    } else {
      setErrors(validationErrors);
    }
  };

  return (
    <div
    className=""
    style={{
      background: colors.gray,
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    }}
  >
       <div className="shadow p-4 rounded" >
        <div  style={{width:"500px",padding:"50px",}}>
      <h2>Registration</h2>
      {successMessage && <div className="alert alert-success">{successMessage}<a href="/login">  Click here to Login</a></div>}
      <form onSubmit={handleSubmit}>
        {Object.keys(initialFormData).map((field) => (
          <div className="form-group" key={field}>
          <label  htmlFor={field}>
            {field.charAt(0).toUpperCase() + field.slice(1)}
          </label>
          <div >
            <input
              type={
                field === 'email'
                  ? 'email'
                  : field === 'password'
                  ? 'password'
                  : field === 'confirmPassword'
                  ? 'password'
                  : field === 'phoneNumber'
                  ? 'number'
                  : 'text'
              }
              name={field}
              value={formData[field]}
              onChange={handleChange}
              className={`form-control ${errors[field] ? 'is-invalid' : ''}`}
            />
            {errors[field] && <div className="invalid-feedback">{errors[field]}</div>}
          </div>
        </div>
        ))}

<div className="text-center mt-4">
              <button type="submit" className="btn btn-primary">
                Register
              </button>
            </div>
      </form>
      <div className="text-center mt-2">
          {/* <Link to="/login">Already have an account? Log in here.</Link> */}
          <a href="/login">Already have an account? Log in here.</a>
        </div>
      </div>
      </div>
    </div>
  );
};

export default Registration;
