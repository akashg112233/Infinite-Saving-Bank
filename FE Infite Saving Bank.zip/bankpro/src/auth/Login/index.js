import React, { useEffect, useState } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link, useHistory } from 'react-router-dom';
import { API_BASE_URL } from '../../config';
import { colors } from '../../helper/colors';



const Login = () => {
  const initialFormData = {
    usernameOrEmail: '',
    password: '',
  };

  const [formData, setFormData] = useState(initialFormData);
  const [errors, setErrors] = useState({});
  const [user,setUsers]=useState();
  const [successMessage, setSuccessMessage] = useState('');


const history = useHistory();

useEffect(() => {
  // This effect runs after the component has mounted

  // Check if the user is already authenticated (e.g., in session storage)
  const userData = sessionStorage.getItem('userData');
  console.log(userData)
  if (userData) {

   const user = JSON.parse(userData);

    if (user.role === 'ADMIN') {
      history.push('/admin-home');
    } else {
      history.push('/home');
    }
  }


}, [user]);

  

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const validationErrors = {};

    for (const field in formData) {
      if (!formData[field]) {
        validationErrors[field] = `${field.charAt(0).toUpperCase() + field.slice(1)} is required`;
      }
    }

    if (Object.keys(validationErrors).length === 0) {
      try {
        const response = await axios.post(`${API_BASE_URL}/login`, formData,{
          headers: {
            'Content-Type': 'application/json',
          },
        });
        console.log(response.status)
        if (response.status >= 200 && response.status < 300) {
          // Store user data in session storage
          sessionStorage.setItem('userData', JSON.stringify(response.data));
          setUsers(response.data);
          console.log('Login successful', response.data,'Harsh');
          
          
        //   setFormData(initialFormData);
        // setErrors({});

        
        
        } else {
          throw new Error(`Login failed with status ${response.status}`);
        }

        
      } catch (error) {
        if (error.response && error.response.status === 401) {
          // Handle the specific 401 error for "Unauthorized"
          validationErrors.username = 'Invalid username or password';
          setErrors(validationErrors);
        } else {
          setSuccessMessage('Login failed');
          console.error('Login failed', error);
        }
      }
    } else {
      setErrors(validationErrors);
    }
  };

  return (
    <div
      className="container"
      style={{
        background: colors.gray,
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <div className="shadow p-4 rounded" style={{ width: '400px', background: colors.white }}>
        <h2 className="text-center mb-4">Login</h2>
        {successMessage && <div className="alert alert-danger">{successMessage}</div>}
        <form onSubmit={handleSubmit}>
          {Object.keys(initialFormData).map((field) => (
            <div className="form-group" key={field}>
              <label htmlFor={field} className="font-weight-bold">
                {field.charAt(0).toUpperCase() + field.slice(1)}
              </label>
              <input
                type={field === 'password' ? 'password' : 'text'}
                name={field}
                value={formData[field]}
                onChange={handleChange}
                className={`form-control ${errors[field] ? 'is-invalid' : ''}`}
              />
              {errors[field] && <div className="invalid-feedback">{errors[field]}</div>}
            </div>
          ))}

          <div className="text-center">
            <button type="submit" className="btn btn-primary mt-3">
              Login
            </button>
          </div>
        </form>
        <div className="text-center mt-2">
          {/* <Link to="/registration">Don't have an account? Singup in here.</Link> */}
          <a href="/registration">Don't have an account? Singup in here.</a>

        </div>
      </div>
    </div>
  );
};

export default Login;
