import React, { createContext, useContext, useState } from 'react';

const SuccessMessageContext = createContext();

export function useSuccessMessage() {
  return useContext(SuccessMessageContext);
}

export function SuccessMessageProvider({ children }) {
  const [successMessage, setSuccessMessage] = useState('');

  return (
    <SuccessMessageContext.Provider value={{ successMessage, setSuccessMessage }}>
      {children}
    </SuccessMessageContext.Provider>
  );
}
